<?php
class Contact_IndexController extends Zend_Controller_Action{
	public function indexAction(){
		
	}
}